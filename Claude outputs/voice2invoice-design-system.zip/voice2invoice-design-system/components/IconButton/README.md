# IconButton

IconButton is a 32px square icon-only control whose `label` is required.

- The consumer provides `label` (becomes `aria-label` and `title`) and one 16px Lucide icon as `children`.
- Rest colour `color-muted`; hover fills `color-raised` and turns the icon `color-ink`.
- Use for row menus, dismiss and toolbar affordances; never for the primary action.

Hand-written from `web/src/components/Button.tsx`.
