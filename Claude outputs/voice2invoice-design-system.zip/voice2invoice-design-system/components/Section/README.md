# Section

Section is a band of content: space and a hairline separate sections, not nested boxes.

- A `color-line-soft` rule above and 28px top padding (`divided={false}` for the first on a page).
- Optional `title` (section-title style), `description` (meta, `color-muted`) and right-aligned `actions` (secondary or ghost Buttons).
- The consumer provides `children`.

Hand-written from `web/src/components/ui.tsx`.
