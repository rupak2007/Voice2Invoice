# Skeleton

Skeleton is the loading placeholder: a `color-raised` block pulsing at 1.8s.

- Shape it with the consumer's own width/height (className or style) to match the content it stands in for; table loading uses rows of a circle, two bars and a pill.
- Mark the container `aria-busy` with a visually hidden "Loading" label.

Hand-written from `web/src/components/ui.tsx`.
