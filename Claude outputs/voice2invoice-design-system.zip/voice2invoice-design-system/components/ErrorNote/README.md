# ErrorNote

ErrorNote says what failed and offers the next move.

- `color-danger-soft` fill, `color-danger-line` border, alert-triangle in `color-danger`; title in `color-ink`, message in `color-dim`.
- The consumer provides `message` (what failed, in plain words), an optional `title` (default "That didn't load"), `onRetry` (renders "Try again") and/or an extra `action`.

Hand-written from `web/src/components/ui.tsx`.
