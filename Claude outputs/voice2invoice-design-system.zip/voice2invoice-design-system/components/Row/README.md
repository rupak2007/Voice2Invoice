# Row

Row is the product's only definition-list row: a label and a value on a hairline.

- Render Rows inside a `<dl>`. Label is meta size in `color-muted`; value is 13px `color-ink`, right-aligned and truncated.
- Set `mono` for IDs and machine values (JetBrains Mono, 12px). Money uses the `tabular` class, not mono.
- The consumer provides `label` and `value`.

Hand-written from `web/src/components/ui.tsx`.
