import type { ReactNode, ButtonHTMLAttributes, InputHTMLAttributes, CSSProperties } from 'react';

/** Source: web/src/components/Button.tsx */
export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'quiet';
export type ButtonSize = 'sm' | 'md' | 'lg';
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  /** Default 'secondary'. Exactly one 'primary' per screen. */
  variant?: ButtonVariant;
  /** Default 'md' (38px tall). sm 32px, lg 44px. */
  size?: ButtonSize;
  children: ReactNode;
}
export function Button(props: ButtonProps): JSX.Element;
/** Class string so links can look identical to buttons. */
export function buttonStyles(variant?: ButtonVariant, size?: ButtonSize, extra?: string): string;
export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  /** Required: announced as aria-label and shown as title. */
  label: string;
  children: ReactNode;
}
export function IconButton(props: IconButtonProps): JSX.Element;

/** Source: web/src/components/ui.tsx */
export type Tone = 'neutral' | 'accent' | 'success' | 'warning' | 'danger';
export function StatusPill(props: { tone?: Tone; icon?: ReactNode; children: ReactNode; className?: string }): JSX.Element;
export type JobStatus = 'invoiced' | 'needs_review' | 'invoice_failed' | 'failed';
export function JobStatusPill(props: { status: JobStatus; processing?: boolean }): JSX.Element;

export function Panel(props: { children: ReactNode; className?: string; pad?: boolean; tone?: 'surface' | 'raised' }): JSX.Element;
export function Section(props: {
  title?: ReactNode; description?: ReactNode; actions?: ReactNode;
  children: ReactNode; className?: string; divided?: boolean;
}): JSX.Element;
/** Render inside a <dl>. */
export function Row(props: { label: ReactNode; value: ReactNode; mono?: boolean }): JSX.Element;

export function Skeleton(props: { className?: string; style?: CSSProperties }): JSX.Element;
export function Empty(props: { icon?: ReactNode; title: string; body?: string; action?: ReactNode }): JSX.Element;
export function ErrorNote(props: { title?: string; message: string; onRetry?: () => void; action?: ReactNode }): JSX.Element;
export function ConceptNote(props: { children: ReactNode }): JSX.Element;

/** The source's INPUT + LABEL class constants, packaged as one labelled field. */
export interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: ReactNode;
  hint?: ReactNode;
  error?: ReactNode;
}
export function TextField(props: TextFieldProps): JSX.Element;

export interface Column<T> {
  key: string;
  header: string;
  /** className for this cell (the source passes Tailwind width/flex classes). */
  cell?: string;
  /** Addition: fixed CSS width, e.g. '120px'. Columns without it share the remaining space. */
  width?: string;
  align?: 'right';
  /** Hide below this breakpoint (sm 640, md 768, lg 1024, xl 1280). */
  from?: 'sm' | 'md' | 'lg' | 'xl';
  render: (row: T) => ReactNode;
}
/** One table for the whole product. rowHref renders each row as a plain <a> (the source uses react-router Link). */
export function DataTable<T>(props: {
  columns: Column<T>[]; rows: T[]; rowKey: (row: T) => string;
  rowHref?: (row: T) => string; empty?: ReactNode;
}): JSX.Element;

export interface ToastInput { title: string; body?: string; tone: Tone }
/** The toast card ToastHost renders; exported for static use. */
export function Toast(props: ToastInput & { onDismiss?: () => void }): JSX.Element;
/** Wrap the app once; toasts stack bottom-right and each clears after 4.2s. */
export function ToastHost(props: { children: ReactNode }): JSX.Element;
/** Inside ToastHost: const toast = useToast(); toast({ title: 'Invoice sent', tone: 'success' }). */
export function useToast(): (t: ToastInput) => void;

/** Source: web/src/components/AppShell.tsx */
export function WaveMark(props: { size?: number; animate?: boolean }): JSX.Element;
export function Brand(props: { size?: number; animate?: boolean }): JSX.Element;
export function PageHeader(props: { title: string; description?: string; actions?: ReactNode; eyebrow?: string }): JSX.Element;

/** Lucide glyphs the product uses, inlined. */
export type IconName = 'check' | 'x' | 'alertTriangle' | 'loader' | 'mic' | 'more' | 'fileText';
export function Icon(props: { name: IconName; size?: number; strokeWidth?: number; spin?: boolean; className?: string }): JSX.Element;
