/* @ds-bundle: {"format":4,"namespace":"V2I","components":[{"name":"Button"},{"name":"IconButton"},{"name":"StatusPill"},{"name":"Panel"},{"name":"Section"},{"name":"Row"},{"name":"Empty"},{"name":"ErrorNote"},{"name":"ConceptNote"},{"name":"TextField"},{"name":"DataTable"},{"name":"Toast"},{"name":"ToastHost"},{"name":"Skeleton"},{"name":"WaveMark"},{"name":"PageHeader"}]} */
/* Hand-written from rupak2007/Voice2Invoice@7fc934e web/src/components (Button.tsx, ui.tsx, AppShell.tsx).
   Same props and variants as the source; Tailwind classes transcribed into bundle.css. Icons are the
   Lucide glyphs the product uses (lucide-react, ISC), inlined as paths. */
(function () {
  var React = window.React, h = React.createElement;
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }
  function omit(o, keys) { var r = {}; for (var k in o) if (keys.indexOf(k) < 0) r[k] = o[k]; return r; }

  var PATHS = {
    check: ['M20 6 9 17l-5-5'],
    x: ['M18 6 6 18', 'm6 6 12 12'],
    alertTriangle: ['m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3', 'M12 9v4', 'M12 17h.01'],
    loader: ['M21 12a9 9 0 1 1-6.219-8.56'],
    mic: ['M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z', 'M19 10v2a7 7 0 0 1-14 0v-2', 'M12 19v3'],
    more: ['M5 12h.01', 'M12 12h.01', 'M19 12h.01'],
    fileText: ['M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z', 'M14 2v4a2 2 0 0 0 2 2h4', 'M10 9H8', 'M16 13H8', 'M16 17H8']
  };
  function Icon(p) {
    var d = PATHS[p.name] || [];
    return h('svg', {
      width: p.size || 16, height: p.size || 16, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor',
      strokeWidth: p.strokeWidth || 2, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true,
      className: p.className, style: p.spin ? { animation: 'v2i-spin 1s linear infinite' } : undefined
    }, d.map(function (x, i) { return h('path', { key: i, d: x }); }));
  }
  var st = document.createElement('style');
  st.textContent = '@keyframes v2i-spin{to{transform:rotate(360deg)}}';
  document.head.appendChild(st);

  /* Button.tsx */
  function buttonStyles(variant, size, extra) {
    return cx('v2i-btn', 'v2i-btn--' + (size || 'md'), 'v2i-btn--' + (variant || 'secondary'), extra);
  }
  function Button(p) {
    var rest = omit(p, ['variant', 'size', 'className', 'children']);
    return h('button', Object.assign({ type: 'button', className: buttonStyles(p.variant, p.size, p.className) }, rest), p.children);
  }
  function IconButton(p) {
    var rest = omit(p, ['label', 'className', 'children']);
    return h('button', Object.assign({ type: 'button', 'aria-label': p.label, title: p.label, className: cx('v2i-iconbtn', p.className) }, rest), p.children);
  }

  /* ui.tsx — status */
  function StatusPill(p) {
    return h('span', { className: cx('v2i-pill', 'v2i-pill--' + (p.tone || 'neutral'), p.className) }, p.icon, p.children);
  }
  var JOB_STATUS = {
    invoiced: { label: 'Invoiced', tone: 'success', icon: 'check' },
    needs_review: { label: 'Needs review', tone: 'warning', icon: 'alertTriangle' },
    invoice_failed: { label: 'Invoice failed', tone: 'danger', icon: 'x' },
    failed: { label: 'Failed', tone: 'danger', icon: 'x' }
  };
  function JobStatusPill(p) {
    if (p.processing) return h(StatusPill, { tone: 'accent', icon: h(Icon, { name: 'loader', size: 11, spin: true }) }, 'Processing');
    var s = JOB_STATUS[p.status] || { label: p.status, tone: 'neutral', icon: 'x' };
    return h(StatusPill, { tone: s.tone, icon: h(Icon, { name: s.icon, size: 11, strokeWidth: s.icon === 'alertTriangle' ? 2 : 3 }) }, s.label);
  }

  /* ui.tsx — layout */
  function Panel(p) {
    return h('div', { className: cx('v2i-panel', p.tone === 'raised' && 'v2i-panel--raised', p.pad !== false && 'v2i-panel--pad', p.className) }, p.children);
  }
  function Section(p) {
    var head = (p.title || p.actions) ? h('header', { className: 'v2i-section__head' },
      h('div', { style: { minWidth: 0 } },
        p.title ? h('h2', { className: 'v2i-section__title' }, p.title) : null,
        p.description ? h('p', { className: 'v2i-section__desc' }, p.description) : null),
      p.actions ? h('div', { className: 'v2i-actions' }, p.actions) : null) : null;
    return h('section', { className: cx(p.divided !== false && 'v2i-section--divided', p.className) }, head, p.children);
  }
  function Row(p) {
    return h('div', { className: 'v2i-row' },
      h('dt', null, p.label),
      h('dd', { className: p.mono ? 'v2i-mono' : undefined }, p.value));
  }

  /* ui.tsx — states */
  function Skeleton(p) { return h('div', { className: cx('skeleton', p.className), style: p.style, 'aria-hidden': true }); }
  function Empty(p) {
    return h('div', { className: 'v2i-empty' },
      p.icon ? h('span', { className: 'v2i-empty__icon' }, p.icon) : null,
      h('p', { className: 'v2i-empty__title' }, p.title),
      p.body ? h('p', { className: 'v2i-empty__body' }, p.body) : null,
      p.action ? h('div', { className: 'v2i-empty__action' }, p.action) : null);
  }
  function ErrorNote(p) {
    return h('div', { className: 'v2i-error', role: 'alert' },
      h(Icon, { name: 'alertTriangle', size: 16, className: 'v2i-error__icon' }),
      h('div', { style: { minWidth: 0, flex: 1 } },
        h('p', { className: 'v2i-error__title' }, p.title || "That didn't load"),
        h('p', { className: 'v2i-error__msg' }, p.message),
        (p.onRetry || p.action) ? h('div', { className: 'v2i-error__actions' },
          p.onRetry ? h('button', { type: 'button', className: 'v2i-retry', onClick: p.onRetry }, 'Try again') : null,
          p.action) : null));
  }
  function ConceptNote(p) {
    return h('div', { className: 'v2i-concept' },
      h('span', { className: 'v2i-concept__tag' }, 'Preview'),
      h('p', { className: 'v2i-concept__text' }, p.children));
  }

  /* ui.tsx — INPUT + LABEL constants, as a field */
  var fid = 0;
  function TextField(p) {
    var idRef = React.useRef(null);
    if (!idRef.current) idRef.current = p.id || 'v2i-field-' + (++fid);
    var id = idRef.current, hintId = id + '-hint';
    var rest = omit(p, ['label', 'hint', 'error', 'id', 'className']);
    return h('div', { className: p.className },
      h('label', { className: 'v2i-label', htmlFor: id }, p.label),
      h('input', Object.assign({ id: id, className: 'v2i-input', 'aria-invalid': p.error ? true : undefined,
        'aria-describedby': (p.error || p.hint) ? hintId : undefined }, rest)),
      (p.error || p.hint) ? h('p', { id: hintId, className: cx('v2i-hint', p.error && 'v2i-hint--error') }, p.error || p.hint) : null);
  }

  /* ui.tsx — DataTable. `cell` is the consumer's className; `width` (a CSS flex-basis/width) is an addition for use without Tailwind. */
  function DataTable(p) {
    if (!p.rows.length && p.empty) return p.empty;
    function cellProps(col, role) {
      return { key: col.key, role: role, className: cx(role === 'columnheader' ? 'v2i-th' : 'v2i-td', col.cell, col.from && 'v2i-from-' + col.from, col.align === 'right' && 'v2i-right'),
        style: col.width ? { flex: '0 0 ' + col.width, width: col.width } : { flex: '1 1 0' } };
    }
    return h('div', { role: 'table', className: 'v2i-table' },
      h('div', { role: 'row', className: 'v2i-thead' }, p.columns.map(function (c) { return h('div', cellProps(c, 'columnheader'), c.header); })),
      h('div', { role: 'rowgroup', className: 'v2i-tbody' }, p.rows.map(function (r) {
        var cells = p.columns.map(function (c) { return h('div', cellProps(c, 'cell'), c.render(r)); });
        return p.rowHref ? h('a', { key: p.rowKey(r), href: p.rowHref(r), role: 'row', className: 'v2i-tr' }, cells)
          : h('div', { key: p.rowKey(r), role: 'row', className: 'v2i-tr' }, cells);
      })));
  }

  /* ui.tsx — toast. Toast is the card ToastHost renders, exported for static use. */
  function Toast(p) {
    var tone = p.tone || 'accent';
    return h('div', { className: 'v2i-toast' },
      h('span', { className: cx('v2i-toast__icon', tone === 'success' && 'v2i-toast__icon--success', tone === 'danger' && 'v2i-toast__icon--danger') },
        h(Icon, { name: tone === 'danger' ? 'x' : 'check', size: 11, strokeWidth: 3 })),
      h('div', { style: { minWidth: 0 } },
        h('p', { className: 'v2i-toast__title' }, p.title),
        p.body ? h('p', { className: 'v2i-toast__body' }, p.body) : null),
      p.onDismiss ? h('button', { type: 'button', className: 'v2i-toast__close', 'aria-label': 'Dismiss', onClick: p.onDismiss }, h(Icon, { name: 'x', size: 13 })) : null);
  }
  var ToastCtx = React.createContext(function () {});
  function useToast() { return React.useContext(ToastCtx); }
  function ToastHost(p) {
    var st = React.useState([]), toasts = st[0], setToasts = st[1];
    var push = React.useCallback(function (t) {
      var id = Date.now() + Math.random();
      setToasts(function (prev) { return prev.concat([Object.assign({}, t, { id: id })]); });
    }, []);
    React.useEffect(function () {
      if (!toasts.length) return;
      var timer = setTimeout(function () { setToasts(function (prev) { return prev.slice(1); }); }, 4200);
      return function () { clearTimeout(timer); };
    }, [toasts]);
    return h(ToastCtx.Provider, { value: push }, p.children,
      h('div', { className: 'v2i-toasts no-print', role: 'status', 'aria-live': 'polite' },
        toasts.map(function (t) {
          return h(Toast, { key: t.id, title: t.title, body: t.body, tone: t.tone,
            onDismiss: function () { setToasts(function (prev) { return prev.filter(function (x) { return x.id !== t.id; }); }); } });
        })));
  }

  /* AppShell.tsx */
  function WaveMark(p) {
    var size = p.size || 30, bars = [7, 13, 19, 13, 7];
    return h('span', { className: cx('v2i-mark', p.animate !== false && 'v2i-mark--animate'), style: { width: size, height: size, borderRadius: (9 / 30) * size }, 'aria-hidden': true },
      bars.map(function (b, i) {
        return h('span', { key: i, className: 'v2i-mark__bar', style: { height: (b / 30) * size + 'px', animationDelay: i * 180 + 'ms' } });
      }));
  }
  function Brand(p) {
    return h('span', { className: 'v2i-brand' }, h(WaveMark, { size: p.size, animate: p.animate }), 'Voice2Invoice');
  }
  function PageHeader(p) {
    return h('div', { className: 'v2i-pagehead' },
      h('div', { style: { minWidth: 0 } },
        p.eyebrow ? h('p', { className: 'v2i-eyebrow' }, p.eyebrow) : null,
        h('h1', { className: 'v2i-pagehead__title' }, p.title),
        p.description ? h('p', { className: 'v2i-pagehead__desc' }, p.description) : null),
      p.actions ? h('div', { className: 'v2i-actions' }, p.actions) : null);
  }

  window.V2I = {
    Button: Button, IconButton: IconButton, buttonStyles: buttonStyles,
    StatusPill: StatusPill, JobStatusPill: JobStatusPill,
    Panel: Panel, Section: Section, Row: Row,
    Empty: Empty, ErrorNote: ErrorNote, ConceptNote: ConceptNote,
    TextField: TextField, Skeleton: Skeleton,
    DataTable: DataTable, Toast: Toast, ToastHost: ToastHost, useToast: useToast,
    WaveMark: WaveMark, Brand: Brand, PageHeader: PageHeader,
    Icon: Icon
  };
})();
