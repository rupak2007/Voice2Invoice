# PageHeader

PageHeader is the page identity: one per screen, always in the same place.

- Optional `eyebrow` (the eyebrow style), a `title` in the page-title style (27px, 24px on small screens), an optional `description` in `color-muted`, and right-aligned `actions` — at most one primary.
- The consumer provides `title` and the rest as needed.

Hand-written from `web/src/components/AppShell.tsx`.
