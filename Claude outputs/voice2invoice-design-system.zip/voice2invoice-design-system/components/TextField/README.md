# TextField

TextField is a labelled text input built from the source's `INPUT` and `LABEL` class strings.

- Label: 12.5px, weight 500, `color-dim`. Always a visible label — never a placeholder alone.
- Input: `color-raised` fill, `color-line` border, `radius-lg`; hover `color-line-strong`; focus `color-accent` border, `color-elevated` fill and a 4px accent ring at 10%.
- The consumer provides `label` and native input props; `hint` for help text, `error` for inline validation (rendered in `color-danger`, wired via `aria-describedby`).

Hand-written from `web/src/components/ui.tsx (INPUT, LABEL)`.
