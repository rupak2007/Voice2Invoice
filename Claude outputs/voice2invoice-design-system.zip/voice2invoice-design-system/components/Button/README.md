# Button

Button is the product's one push-button, in five variants and three sizes.

- Exactly one `primary` per screen: teal (`color-accent`) is the signal colour, so a second solid-teal button devalues the first.
- `secondary` is the default for everything else; `ghost` for low-emphasis toolbar actions; `quiet` for inline teal text actions; `danger` for destructive actions (pair with a confirmation).
- Sizes: `sm` 32px, `md` 38px (default), `lg` 44px. Label is sentence case, a verb first ("Create invoice").
- The consumer provides `children` (label, optionally a 16px Lucide icon before it) and any native button props. Disabled drops to 40% opacity.
- For a link that must look like a button, use `buttonStyles(variant, size)` on an `<a>`.

Hand-written from `web/src/components/Button.tsx`.
