# ToastHost

ToastHost is the provider that stacks toasts bottom-right and clears each after 4.2s.

- Wrap the app once. Anywhere inside it, `const toast = useToast()`, then `toast({ title, body?, tone })`.
- Toasts sit in a polite live region (`role="status"`) and are hidden when printing (`.no-print`).
- The consumer provides `children` (the app).

Hand-written from `web/src/components/ui.tsx`.
