# StatusPill

StatusPill shows a status as a word plus a shape — never colour alone.

- The consumer provides `tone` (`neutral`, `accent`, `success`, `warning`, `danger`), an 11px icon and the label.
- `JobStatusPill` maps job states: Invoiced → success + check; Needs review → warning + alert-triangle; Invoice failed / Failed → danger + x; `processing` → accent + spinning loader.
- Invoice states follow the same pattern: Not created (neutral, dashed circle), Issued (accent), Sent (success), Send failed (warning), Failed (danger). Derive them strictly from what Stripe returned.
- `accent` tone means AI or processing activity, nothing else.

Hand-written from `web/src/components/ui.tsx`.
