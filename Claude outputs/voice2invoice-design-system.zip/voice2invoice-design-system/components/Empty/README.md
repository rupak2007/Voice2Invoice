# Empty

Empty is the empty state, and it always names the action that fills it.

- Optional 20px Lucide `icon` in an accent-tinted 44px tile; a `title` (empty-title style); a one-sentence `body` in `color-muted`; an `action` (usually the screen's one primary Button).
- Write the title as a plain fact ("No jobs yet") and the body as what to do next. No illustrations, no robots.

Hand-written from `web/src/components/ui.tsx`.
