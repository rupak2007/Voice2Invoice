# Toast

Toast is the confirmation card: `color-elevated`, a `color-line` hairline, `radius-xl` and `shadow-lg`, one of the few things allowed a shadow.

- A 20px round icon (check for success and accent, x for danger), a 13px title in `color-ink` and an optional one-line body in `color-muted`.
- Use it through `ToastHost` and `useToast`. Render `Toast` directly only for static layouts. The consumer provides `title`, `tone` and optionally `body` and `onDismiss`.
- Confirm what happened in past tense ("Invoice sent"). Name the next step in the body, if there is one.

Hand-written from `web/src/components/ui.tsx`.
