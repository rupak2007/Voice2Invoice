# WaveMark

WaveMark is the product mark: five teal bars (7·13·19·13·7 of 30) breathing slowly in an accent-tinted tile.

- Default 30px; the bar heights and 9px corner scale with `size`. Its idle wave is the product's only idle motion — pass `animate={false}` where motion would distract.
- `Brand` pairs it with the "Voice2Invoice" wordmark set in Geist 600 at 14px, `color-ink`, 10px gap.
- Never recolour, outline or add a glow to the mark.

Hand-written from `web/src/components/AppShell.tsx`.
