# Panel

Panel is a raised plane for panels and documents — never a wrapper by reflex.

- `color-surface` fill (or `color-raised` with `tone="raised"`), a `color-line` hairline, `radius-xl`, 20px padding (`pad={false}` to remove).
- No shadow: depth comes from the surface ladder and hairlines. Never nest Panels; separate content inside with `Section` or `Row` hairlines.
- The consumer provides `children`.

Hand-written from `web/src/components/ui.tsx`.
