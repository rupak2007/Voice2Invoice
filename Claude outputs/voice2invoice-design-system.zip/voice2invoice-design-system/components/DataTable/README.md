# DataTable

DataTable is the one table for the whole product: hairline row dividers, generous 14px row padding, whole-row links and no boxed cells.

- The consumer provides `columns` (`key`, `header`, `render(row)`, optional `align: 'right'` for money, `from` to hide a column below a breakpoint, `cell` className and `width`), `rows`, `rowKey`, and optionally `rowHref` (makes each row a link that fills `color-raised` on hover) and `empty` (an `Empty` shown when there are no rows).
- Headers use the eyebrow style. Right-align amounts and set them `tabular`. Put status in a `StatusPill` column.
- While loading, show `Skeleton` rows in place of the table.
- `width` is an addition for use without Tailwind; the source passes Tailwind width classes through `cell`. Rows link with a plain `<a>` where the source uses react-router `Link`.

Hand-written from `web/src/components/ui.tsx`.
