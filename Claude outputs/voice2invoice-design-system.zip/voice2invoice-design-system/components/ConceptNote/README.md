# ConceptNote

ConceptNote marks a screen whose data is real but whose actions are not yet wired to a backend.

- A "Preview" tag in accent plus one sentence in `color-muted`, on `color-raised`.
- Use it so a demo surface can never be mistaken for a shipping one. The consumer provides the sentence as `children`.

Hand-written from `web/src/components/ui.tsx`.
