# Logos

- `wavemark.svg` — the WaveMark at rest, drawn from the `WaveMark` component's exact geometry (30×30 tile, 9px corner, five 2px bars of 7·13·19·13·7 with 2px gaps). Ink: `color-accent` (#2dd4bf) bars on a `color-accent-soft` tile with a `color-accent-line` border. Use it on `color-base` or `color-surface` only; it has no light-ground version.
- In product UI prefer the live `WaveMark` / `Brand` components, which animate the bars.
- There is no separate wordmark file: set "Voice2Invoice" in Geist 600, `color-ink`, beside the mark (see `Brand`).
