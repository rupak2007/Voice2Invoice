Voice2Invoice is a voice-first invoicing tool for field technicians: speak about a job, get a professional invoice. It handles money, so every screen puts trust first. The identity is **dark · teal · voice · precision · restraint**: a restrained B2B operations tool, not a consumer app and not "AI magic".

## Content fundamentals

- Write in sentence case, in plain operational language. Buttons start with a verb: "Record job", "Create invoice", "Try again".
- Put the billing facts first: customer, amount, invoice status, validation status.
- Show status as a word plus a shape, never colour alone: "✓ Invoiced", "! Needs review", "× Failed". Use `StatusPill` / `JobStatusPill`.
- Every empty state names the action that fills it ("No invoices yet" + "Record a job"). Every error says what failed and offers the next move ("Stripe rejected the customer email. Fix it and try again.").
- Label anything that is not live yet with `ConceptNote` ("Preview"), so a demo surface is never mistaken for a shipping one.
- Format money consistently in the project's currency ($250, $1,250, $12,450), with the `tabular` class (tabular-nums). Never convert currencies silently. Timers, quantities and IDs use tabular figures too.
- Show AI through the workflow itself (processing status, extracted fields, validation), never through robots, sparkles or glowing gradients. No emoji as interface icons.

## Visual foundations

**Colour.** Dark is the product's theme; Light is for surfaces that must read as paper (shared invoice views, docs, email). Set `data-theme="light"` on a root element to switch. Both themes use the same token names, so never hard-code a hex. Depth comes from four flat surface layers separated by hairlines: `color-base` (canvas) → `color-surface` (panels, documents) → `color-raised` (inputs, secondary buttons, hover) → `color-elevated` (focus, toasts). `color-base-soft` is for the sidebar and recessed bands.
- Structure is drawn with hairlines: `color-line` for panel and input borders, `color-line-soft` for row and section dividers, `color-line-strong` for hover borders.
- Text: `color-ink` for primary text, `color-dim` for labels and secondary text, `color-muted` for metadata and descriptions. `color-muted` is the quietest text allowed (4.5:1 on `color-surface` in Dark, at least 5.1:1 on every ground in Light). Never go dimmer. In Dark, never put it on anything lighter than `color-raised`.
- Teal is a signal, not a theme. `color-accent` marks voice, AI activity, focus and the single primary action on a screen. Nothing else. Text on a solid accent fill is `color-accent-ink` (dark teal in Dark, white in Light, where the accent is a deeper teal). Tinted accent content uses `color-accent-soft` with a `color-accent-line` border.
- `color-record` (rose) is only for live recording, deliberately distinct from `color-danger`.
- Semantic colours (`color-success`, `color-warning`, `color-danger`, each with `-soft` fill and `-line` border) carry meaning only, never decoration. Success and danger here are a green and a red at similar lightness, so the icon and word are mandatory.

**Type.** Set UI text in the `sans` family (Geist, falling back to Inter Tight). Use `mono` (JetBrains Mono) only for IDs and machine values. All three are Google Fonts: load Geist 400–700, Inter Tight 400–700 and JetBrains Mono 400–500.
- Styles: `page-title` (27px/600, −0.028em, one per screen; `page-title-sm` 24px on small screens), `section-title`, `empty-title`, `body` (14px/1.55, the default), `control` (buttons and inputs), `body-sm`, `meta`, `pill`, and `eyebrow`. The eyebrow is the one label style: 10.5px, 600, 0.1em tracking, uppercase, `color-muted`. Table headers use it.
- Headlines are tight and confident, never oversized. No huge type on dashboard content.

**Spacing and layout.** 4px base unit (`space-1`). Panels pad `space-5`, sections open with a hairline and `space-7`, and page gutters step `space-4` → `space-6` → `space-8` by breakpoint. Pages use width well: a max of 1320px (1480px at 2xl), with wide views at 1680px (1960px). Don't leave a narrow column floating in empty margins. Prefer information density over decoration.

**Radii.** `radius-lg` (12px) for buttons, inputs and table rows. `radius-xl` (16px) for panels, notes and toasts. `radius-full` for pills. `radius-sm` for skeletons. Nothing is extremely rounded.

**Light theme.** It is built on the print stylesheet: `color-surface` is the white page, `color-ink` is #111 and `color-line` is #ddd. Accents and status colours are darkened so that each one reaches at least 4.5:1 on every ground and on its own pill fill. Light shadows are softer. The mic glow keeps its shape in the deeper teal.

**Borders and shadows.** Separate things with hairlines and surface steps, not shadows. Shadows (`shadow-sm`, `shadow-md`, `shadow-lg`) are only for things that float above the page: menus, toasts, dialogs. Never put a border and a heavy shadow on the same element.
- Exactly one element in the product may glow: the live microphone, with `shadow-mic-live`, and only while it is actually listening.

**States.** Focus is a solid 2px `color-accent` outline at 2px offset. Inputs on focus switch to an accent border and `color-elevated` fill with a 4px accent ring at 10%. Disabled controls drop to 40% opacity. Hover moves one step up the surface ladder. Loading uses `Skeleton` rows shaped like the content they replace.

**Motion.** 120ms for micro changes (hover, colour), 200ms for panels (fade, slide-up), 320ms for state changes (content rising in). Only the waveform, AI progress, state changes and focus animate. The idle WaveMark breathe is the one ambient motion. A field the AI just resolved flashes `color-accent-soft` for 1.4s. Honour `prefers-reduced-motion`: every animation collapses to near zero.

**Print.** Invoices print as a light document (white page, #111 text, #ddd rules, 16mm margins), never as a dark app screen. Hide app chrome with `.no-print`.

## Iconography

- Use Lucide (`lucide-react`) only. Never mix icon libraries.
- Sizes: 11–12px inside pills and metadata, 16px in controls, 18px in navigation, 20px on primary actions and empty-state tiles, 24px for major features. Keep Lucide's default stroke; pills use strokeWidth 3 for check and x.
- Icons inherit `currentColor` from their text token. Icon-only buttons always carry a label (`IconButton`).
- The mark is the WaveMark (`assets/Logos/wavemark.svg`; live: the `WaveMark` and `Brand` components).

## Components

Build every screen from `Button`, `IconButton`, `StatusPill`/`JobStatusPill`, `Panel`, `Section`, `Row`, `Empty`, `ErrorNote`, `ConceptNote`, `TextField`, `Skeleton`, `DataTable`, `Toast`/`ToastHost`/`useToast`, `WaveMark`/`Brand` and `PageHeader`, all under `window.V2I`. That gives one spacing rhythm, one type scale and one border treatment, so no page drifts into looking bespoke. Only one `primary` Button per screen.

## Not synced

Synced from the local `main` checkout at commit 7fc934e (web/src/index.css, web/index.html, the component files). Last revised: added the Light theme, DataTable and Toast.
- The components are hand-written, not built from the repository. They are transcribed from `Button.tsx`, `ui.tsx` and `AppShell.tsx` with the same props, and use `bundle.css` in place of Tailwind.
- Components not included, because they depend on the app, the router or its data: AppShell, Nav, GlobalSearch, AiProgress, ProcessingStage, VoiceStage, InvoiceEditor and InvoiceDocument.
- DataTable rows link with a plain `<a>` instead of react-router's `Link`. DataTable also has a `width` column prop, which the source doesn't have.
- The Light theme is not in the repository. It is derived from the print colours; see Visual foundations.
- No font files were copied: the product loads Geist, Inter Tight and JetBrains Mono from Google Fonts.
- There are no logo files in the repository. `wavemark.svg` is drawn from the `WaveMark` component's code values.
- The `rgb(0 0 0 / a)` shadows are written as the equivalent `rgba()`.
- `design.md` calls for a light default theme, but the shipped code is dark-only. So Dark stays first (the default) and Light is the second theme.
